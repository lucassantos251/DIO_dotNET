---
name: Request for driver version support
about: Ask maintainers for support of yet another Nvidia driver
title: New driver support (version XXX.XX)
labels: enhancement
assignees: ''

---

**Please provide details about your environment (please complete the following information)**
- Nvidia driver version: [e.g. 410.48]
- GPU Model: [e.g. GTX 1070]
- OS: [e.g. Ubuntu 18.04]
- [x] I'm willing to participate in testing of new patch version
