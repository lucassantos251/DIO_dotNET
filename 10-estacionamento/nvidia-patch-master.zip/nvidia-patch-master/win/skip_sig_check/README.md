Registry values to bypass DLL signature check in Nvidia streaming software for Windows.

Instructions:

1. Download raw file. Right click on "Raw" button [on this page](skip_sig_check.reg) and then click "Save as...".
2. Apply (merge) file. Double click on downloaded file and confirm.
