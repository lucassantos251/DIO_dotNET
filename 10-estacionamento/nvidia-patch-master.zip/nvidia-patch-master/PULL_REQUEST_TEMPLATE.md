**Purpose of proposed changes**

Please give us an idea about why these changes should be applied. If actual PR fixes some opened issues, please reference them here.

**Essential steps taken**

If possible, please highlight most essential parts of your solution in order to speed up our understanding of changes made.
